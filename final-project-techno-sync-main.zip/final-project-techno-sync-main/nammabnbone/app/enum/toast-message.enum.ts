export enum ToastMessage {
	LOGGED_IN = 'Logged in!',
     REGISTERED = 'Registered!',
     LISTING_RESERVED = 'Listing reserved!',
     SOMETHING_WENT_WRONG = 'Something went wrong!',
}