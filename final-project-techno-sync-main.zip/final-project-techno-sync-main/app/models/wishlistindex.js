import Property from './wishlist.js';

export default {
    Property
}