import booking from "./bookingreservation.js";
import Property from './property.js';
export default {
    booking,
    Property
}